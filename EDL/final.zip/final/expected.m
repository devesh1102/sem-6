clear
close all
R= 12000
C = 4.7*10^-9
samples = 1000
F = linspace(100,45000,samples)
for j = 1: samples
    eqn = R/(R*i*2*pi*F(1,j)*C +1);
    real11 = real (eqn)  ;
    imag11 = imag(eqn)
    mag(j) = sqrt(real11*real11 + imag11*imag11);
    phase(j) = atan(imag11/real11)*180/pi;
end
figure(55)
plot(F,mag)
xlabel(' F(in Hz)') 
ylabel('Magnitude') 
title(['MAGNITUDE expected(  R ',num2str(R),', C',num2str(C)])

figure(66)
plot(F,phase)
xlabel(' F(in Hz)') 
ylabel('phase') 
title(['Phase expected ' R ',num2str(R),', C',num2str(C)])